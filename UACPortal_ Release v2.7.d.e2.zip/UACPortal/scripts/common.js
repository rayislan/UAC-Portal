﻿function updateMainFr(UpID, checkObjID) {
    var obj = document.getElementById(checkObjID);
    if (!obj.value) {
        alert("Please select PFY and click go button");
        return false;
    }
    __doPostBack(UpID, '');
    return false;
}

function openReport(rptType) {
    $(document).ready(function () {
        if ($('#' + $('#hdnddArcHistoryId').val()).length) {
            window.open("./RptViewer.aspx?rptType=" + rptType + "&ArcTime=" + $('#' + $('#hdnddArcHistoryId').val()).val(), "Reports", "toolbar=no,scrollbars=yes,resizable=yes");
        }
        else {
            window.open("./RptViewer.aspx?rptType=" + rptType, "Reports", "toolbar=no,scrollbars=yes,resizable=yes");
        }
        return false;
    });
}

function openFile(fileName) {
    $(document).ready(function () {
        var param = { 'FileName': fileName };
        OpenWindowWithPost("./ViewDocFile.aspx", "toolbar=no,scrollbars=yes,resizable=yes", "NewFile", param);
        return false;
    });
}

function OpenWindowWithPost(url, windowoption, name, params) {
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", url);
    form.setAttribute("target", name);

    for (var i in params) {
        if (params.hasOwnProperty(i)) {
            var input = document.createElement('input');
            input.type = 'text';
            input.setAttribute("style", "display:none");
            input.name = i;
            input.value = params[i];
            form.appendChild(input);
        }
    }

    document.body.appendChild(form);

    //note I am using a post.htm page since I did not want to make double request to the page 
    //it might have some Page_Load call which might screw things up.
    //window.open("", name, windowoption);
    form.submit();

    document.body.removeChild(form);
}

function openDoc(docId, docType) {
    $(document).ready(function () {
        var param = { 'DocId': docId, 'docType': docType };
        OpenWindowWithPost("/ViewUACDocs.aspx", "toolbar=no,scrollbars=yes,resizable=yes", "UACDocs", param);
        return false;
    });
}
var myWidth = 0, myHeight = 0;

function resetTDSize() {
    if (typeof (window.innerWidth) == 'number') {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    }
    else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    }
    else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
        //IE 4 compatible


        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }
    if (document.getElementById("tdLeft")) {
        document.getElementById("tdLeft").style.width = 161;
    }
}


function DeleteRecord() {
    var didConfirm = confirm("Are you sure you want to delete this record?");
    if (didConfirm) {

        return true;
    }
    else {
        return false;
    }
}

function confirmLogoff() {
    var didConfirm = confirm("Are you sure you want to log off?");
    if (didConfirm) {
        return true;
    }
    else {
        return false;
    }
}


function PopulateUACInfo(infoType) {
    $(document).ready(function () {
        var imgSrc = $("#img" + infoType).attr('src');
        var UACId = $("#hdnUACProgId").val();
        if (imgSrc == 'Images/plus.gif') {
            $("#img" + infoType).attr('src', 'Images/minus.gif');
            $('#sp' + infoType).empty().append('<img src="Images/loader03.gif" style="width: 16px; height: 16px" id="imgLoader">');
            $('#sp' + infoType).append('&nbsp;&nbsp;Loading ...');
            $('#hdnInfoType').val(infoType);
            $.ajax({
                type: "POST",
                url: "UACWebServices.asmx/getUACInfo",
                data: '{UAC_ID: ' + UACId + ', infoType: "' + infoType + '", isHistoryInfo: 0}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: OnUACInfoPopulated,
                failure: function (data) {
                    alert(data.d);
                }
            });
        }
        else if (imgSrc == 'Images/minus.gif') {
            $("#img" + infoType).attr('src', 'Images/plus.gif');
            $('#sp' + infoType).empty();
        }
    });
}

function getAddendumForSIR(sirId, eventId) {
    var imgSrc = $("#img" + sirId).attr('src');
    $('#hdnEventID').val(eventId);    
    $(document).ready(function () {
        if (imgSrc == 'Images/plus.gif') {
            $("#img" + sirId).attr('src', 'Images/minus.gif');
            $('#sp' + sirId).empty().append('<img src="Images/loader03.gif" style="width: 16px; height: 16px" id="imgLoader">');
            $('#sp' + sirId).append('&nbsp;&nbsp;Loading ...');
            //$('#hdnInfoType').val(infoType);
            $.ajax({
                type: "POST",
                url: "UACWebServices.asmx/getAddendumForSIR",
                data: '{sirId: ' + sirId + '}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: OnAddendumInfoPopulated,
                failure: function (data) {
                    alert(data.d);
                }
            });
        }
        else if (imgSrc == 'Images/minus.gif') {
            $("#img" + sirId).attr('src', 'Images/plus.gif');
            $('#sp' + sirId).closest("tr").next().remove();
        }
    });
}

function OnAddendumInfoPopulated(response) {
    var xmlDoc = $.parseXML(response.d);
    var xml = $(xmlDoc);
    var uacInfo = xml.find("Table");
    var headers = [];
    var rows = [];
    var sirIdThis;
    headers.push("<tr style='background-color: #6699cc; color: white'>");
    //headers.push("<th style='width: 20%'>Addendum ID</td>");
    headers.push("<th style='width: 20%'>Date Completed</td>");
    headers.push("<th style='width: 20%'>Last Updated</td>");
    headers.push("<th style='width: 10%'>Staff</td>");
    headers.push("<th style='width: 8%' colspan='2'>Options</td>");
    headers.push("<th style='width: 10%'>&nbsp;</td>");
    headers.push("</tr>");
    // rows section
    var i = 1;
    $.each(uacInfo, function () {
        var uacInfo = $(this);
        if (i % 2 == 0) {
            rows.push("<tr style='background-color: #ccffff'>");
        }
        else {
            rows.push("<tr>");
        }
        sirIdThis = $(this).find("SIR_ID").text();

        //rows.push("<td>" + $(this).find("ADDENDUM_ID").text() + "</td>");
        rows.push("<td>" + $(this).find("DATE_CREATED").text() + "</td>");
        rows.push("<td>" + $(this).find("UPTIME").text() + "</td>");
        rows.push("<td>" + $(this).find("UPUSER").text() + "</td>");
        //rows.push("<td>" + "<input type=\"button\" value=\"Edit Addendum\" />" + "</td>");
        //rows.push("<td><a href='Addendum.aspx?sirId=" + $(this).find("SIR_ID").text() + "'><img src='Images/edit.gif' border='0'></a></td>");
        rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"UACSIR.aspx\", \"" + $(this).find("SIR_ID").text() + "\"," + "\"" + $(this).find("EVENT_TYPE").text() + "\");'><img src='Images/edit.gif' border='0' alt='edit'></a></td>");
        rows.push("<td style='width: 4%'><a href='javascript:loadPdfForAddendum(\"UACSIR.aspx\", \"" + $(this).find("SIR_ID").text() + "\"," + "\"" + $(this).find("EVENT_TYPE").text() + "\");'><img src='Images/pdf.gif' border='0' alt='export to pdf'></a></td>");
        //rows.push("<td style='width: 3%'><a href='javascript:deleteAddendum(\"UACSIR.aspx\", \"" + $(this).find("SIR_ID").text() + "\");'><img src='Images/delete.gif' border='0' alt='delete'></a></td>");
        rows.push("</tr>");
        i++;
    });
    var top = "<table style='margin: 0px auto;width: 100%'>";
    var bottom = "</table>";
    var table = top + headers.join("") + rows.join("") + bottom;
    //$('#sp14').empty().html(table);
    $('#sp' + sirIdThis).empty().closest("tr").after("<tr><td></td><td colspan = '999'>" + table + "</td></tr>")
}


function OnUACInfoPopulated(response) {
    var infoType = $('#hdnInfoType').val();
    var xmlDoc = $.parseXML(response.d);
    var xml = $(xmlDoc);
    var uacInfo = xml.find("Table");
    var headers = [];
    var rows = [];

    if (infoType == "EducationPlan" || infoType == "UACDocuments") {
        headers.push("<tr style='background-color: #6699cc; color: white'>");
        headers.push("<th style='width: 20%'>File Name</td>");
        headers.push("<th style='width: 10%'>File Type</td>");
        headers.push("<th style='width: 10%'>File Size(kb)</td>");
        headers.push("<th style='width: 10%'>Date Uploaded</td>");
        headers.push("<th style='width: 10%'>Uploaded By</td>");
        headers.push("<th style='width: 30%'>Program Name</td>");
        headers.push("<th colspan='2' style='width: 4%; text-align: center'>Options</td>");
        headers.push("<th stype='width: 6%'>&nbsp;</td>");
        headers.push("</tr>");
        // rows section
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if (i % 2 == 0) {
                rows.push("<tr style='background-color: #ccffff'>");
            }
            else {
                rows.push("<tr>");
            }
            if (infoType == "UACDocuments") {
                rows.push("<td><a class='blank' href='#' onclick='openDoc(\"" + $(this).find("DOC_ID").text() + "\");' >" + $(this).find("ORG_FILE_NAME").text() + "</a></td>");
            }
            else {
                rows.push("<td><a class='blank' href='#' onclick='openFile(\"" + $(this).find("FILE_NAME").text() + "\");' >" + $(this).find("ORG_FILE_NAME").text() + "</a></td>");
            }
            rows.push("<td>" + $(this).find("FILE_TYPE").text() + "</td>");
            rows.push("<td>" + $(this).find("FILE_SIZE").text() + "</td>");
            rows.push("<td>" + $(this).find("LAST_UPDATED").text() + "</td>");
            rows.push("<td>" + $(this).find("STAFF").text() + "</td>");
            rows.push("<td>" + $(this).find("PROGRAM_NAME").text() + "</td>");
            if (infoType == "UACDocuments") {
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='UD" + i + "' href='JavaScript: deleteRecord(\"UACDocuments\",\"" + $(this).find('DOC_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
            }
            else {
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='ED" + i + "' href='JavaScript: deleteRecord(\"EducationPlan\",\"" + $(this).find('PLACEMENT_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("PLACEMENT_ID").text() + "\", \"EducationPlacement\");'><img src='Images/pdf.gif' border='0'></a></td>");
            }

            //rows.push("<td>&nbsp;</td>");
            rows.push("</tr>");
            i++;
        });
        var top = "<table style='margin: 0px auto;width: 100%'>";
        var bottom = "</table>";
        var table = top + headers.join("") + rows.join("") + bottom;
        $("#sp" + infoType).empty().html(table);
    }
    else if (infoType == "Sponsor") {
        headers.push("<tr style='background-color: #6699cc; color: white'>");
        headers.push("<th style='width: 10%'>First Name</td>");
        headers.push("<th style='width: 10%'>Last Name</td>");
        headers.push("<th style='width: 4%'>SSN</td>");
        headers.push("<th style='width: 10%; white-space: nowrap'>Primary Sponsor</td>");
        headers.push("<th style='width: 20%'>Address</td>");
        headers.push("<th style='width: 8%'>City</td>");
        headers.push("<th style='width: 5%'>State</td>");
        headers.push("<th style='width: 6%; white-space: nowrap'>P Counter</td>");
        headers.push("<th style='width: 6%; white-space: nowrap'>A Counter</td>");
        headers.push("<th style='width: 4%'>Sponsor Flag</td>");
        headers.push("<th style='width: 6%'>Address Flag</td>");
        headers.push("<th colspan='2' style='width: 12%; text-align: center'>Options</td>");
        headers.push("<th stype='width: 2%'>&nbsp;</td>");
        headers.push("</tr>");
        // rows section
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if (i % 2 == 0) {
                rows.push("<tr style='background-color: #ccffff'>");
            }
            else {
                rows.push("<tr>");
            }
            rows.push("<td>" + $(this).find("FIRST_NAME").text() + "</td>");
            rows.push("<td>" + $(this).find("LAST_NAME").text() + "</td>");
            rows.push("<td>" + $(this).find("SSN").text() + "</td>");
            rows.push("<td>" + $(this).find("CURR_SPONSOR").text() + "</td>");
            rows.push("<td>" + $(this).find("ADDRESS").text() + "</td>");
            rows.push("<td>" + $(this).find("CITY").text() + "</td>");
            rows.push("<td>" + $(this).find("STATE").text() + "</td>");
            rows.push("<td>" + $(this).find("P_COUNTER").text() + "</td>");
            rows.push("<td>" + $(this).find("A_COUNTER").text() + "</td>");
            rows.push("<td><span title='" + $(this).find("FLAG_NOTE").text() + "'>" + $(this).find("FLAG").text() + "</span></td>");
            rows.push("<td><span title='" + $(this).find("FLAG_ADDRESS_NOTE").text() + "'>" + $(this).find("FLAG_ADDRESS").text() + "</span></td>");
            rows.push("<td><a href='javascript:loadFunctionPages(\"NewSponsor.aspx\", \"" + $(this).find("SPONSOR_ID").text() + "\");'><img id='EditNewSponsor_" + $(this).find("SPONSOR_ID").text() + "' src='Images/edit.gif' border='0' alt='Sponsor Info'></a></td>");
            if ($(this).find("CURR_SPONSOR").text() == "No" && (($("#hdnRoleType").val() == "HQ" && $("#hdnUserPrivilege").val() == "Admin") || ($("#hdnRoleType").val() == "FFS" && $("#hdnUserPrivilege").val() == "Approve"))) {
                rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"Sponsor\",\"" + $(this).find('SPONSOR_ID').text() + "_" + $(this).find('UAC_ID').text() + "\");'>Dis-Assign</a></td>");
            }
            else {
                //rows.push("<td>&nbsp;</td>");
            }
            rows.push("<td><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("SPONSOR_ID").text() + "\", \"NewSponsor\");'><img id='PDFNewSponsor_" + $(this).find("SPONSOR_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            rows.push("</tr>");
            i++;
        });
        var top = "<table style='margin: 0px auto;width: 100%'>";
        var bottom = "</table>";
        var table = top + headers.join("") + rows.join("") + bottom;
        $("#sp" + infoType).empty().html(table);
    }
    else if (infoType == "ReleaseRequest") {
        headers.push("<tr style='background-color: #6699cc; color: white'>");
        headers.push("<th style='width: 10%; white-space: nowrap'>Date Completed</td>");
        headers.push("<th style='width: 10%'>Last Updated</td>");
        headers.push("<th style='width: 20%'>Program Name</td>");
        headers.push("<th style='width: 25%'>Cancellation Reason</td>");
        headers.push("<th style='width: 10%'>Staff</td>");
        headers.push("<th colspan='3' style='width: 12%; text-align: center'>Options</td>");
        headers.push("<th stype='width: 12%'>&nbsp;</td>");
        headers.push("</tr>");
        // rows section
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if (i % 2 == 0) {
                rows.push("<tr style='background-color: #ccffff'>");
            }
            else {
                rows.push("<tr>");
            }

            rows.push("<td>" + $(this).find("DATE_COMPLETED").text() + "</td>");
            rows.push("<td>" + $(this).find("LAST_UPDATED").text() + "</td>");
            rows.push("<td>" + $(this).find("PROGRAM_NAME").text() + "</td>");
            rows.push("<td>" + $(this).find("CANCELLATION_REASON").text() + "</td>");
            rows.push("<td>" + $(this).find("STAFF").text() + "</td>");
            rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"ReleaseRequest.aspx\", \"" + $(this).find("RELEASE_ID").text() + "\");'><img id='EditRelease_" + $(this).find("RELEASE_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
            if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                //rows.push("<td>&nbsp;</td>");
            }
            else {
                rows.push("<td><a id='RR" + i + "' href='JavaScript: deleteRecord(\"ReleaseRequest\",\"" + $(this).find('RELEASE_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
            }
            rows.push("<td ><a href='javascript:loadFunctionPages(\"DischargeDetail.aspx\", \"" + $(this).find("RELEASE_ID").text() + "\", \"ReleaseRequest\");'><img id='PDFRelease_" + $(this).find("RELEASE_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            rows.push("<td>&nbsp;</td>");
            rows.push("</tr>");
            i++;
        });
        var top = "<table style='margin: 0px auto;width: 100%'>";
        var bottom = "</table>";
        var table = top + headers.join("") + rows.join("") + bottom;
        $("#sp" + infoType).empty().html(table);
    }
    else if (infoType == "HomeStudyCaseReferral") {
        headers.push("<tr style='background-color: #6699cc; color: white'>");
        headers.push("<th style='width: 10%; white-space: nowrap'>Referral ID</td>");
        headers.push("<th style='width: 12%'>Sponsor Name</td>");
        headers.push("<th style='width: 12%'>Sponsor Address</td>");
        headers.push("<th style='width: 10%'>City</td>");
        headers.push("<th style='width: 5%'>State</td>");
        headers.push("<th style='width: 10%'>Zip Code</td>");
        headers.push("<th style='width: 10%'>Referral Status</td>");
        headers.push("<th style='width: 12%; text-align: center'>Options</td>");
        headers.push("<th stype='width: 12%'>&nbsp;</td>");
        headers.push("</tr>");
        // rows section
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if (i % 2 == 0) {
                rows.push("<tr style='background-color: #ccffff'>");
            }
            else {
                rows.push("<tr>");
            }

            rows.push("<td>" + $(this).find("REFERRAL_ID").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_NAME").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_ADDRESS").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_CITY").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_STATE").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_ZIPCODE").text() + "</td>");
            rows.push("<td>" + $(this).find("REFERRAL_STATUS").text() + "</td>");
            rows.push("<td style='width: 12%; text-align: center'><a href='javascript:loadFunctionPages(\"HomeStudyCaseReferral.aspx\", \"" + $(this).find("HOMESTUDY_ID").text() + "\");'><img id='EditHomeStudy_" + $(this).find("HOMESTUDY_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
            rows.push("<td>&nbsp;</td>");
            rows.push("</tr>");
            i++;
        });
        var top = "<table style='margin: 0px auto;width: 100%'>";
        var bottom = "</table>";
        var table = top + headers.join("") + rows.join("") + bottom;
        $("#sp" + infoType).empty().html(table);
    }
    else if (infoType == "PostReleaseServicesReferral") {
        headers.push("<tr style='background-color: #6699cc; color: white'>");
        headers.push("<th style='width: 10%; white-space: nowrap'>Referral ID</td>");
        headers.push("<th style='width: 12%'>Sponsor Name</td>");
        headers.push("<th style='width: 12%'>Sponsor Address</td>");
        headers.push("<th style='width: 10%'>City</td>");
        headers.push("<th style='width: 5%'>State</td>");
        headers.push("<th style='width: 10%'>Zip Code</td>");
        headers.push("<th style='width: 10%'>Referral Status</td>");
        headers.push("<th style='width: 12%; text-align: center'>Options</td>");
        headers.push("<th stype='width: 12%'>&nbsp;</td>");
        headers.push("</tr>");
        // rows section
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if (i % 2 == 0) {
                rows.push("<tr style='background-color: #ccffff'>");
            }
            else {
                rows.push("<tr>");
            }

            rows.push("<td>" + $(this).find("REFERRAL_ID").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_NAME").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_ADDRESS").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_CITY").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_STATE").text() + "</td>");
            rows.push("<td>" + $(this).find("SPONSOR_ZIPCODE").text() + "</td>");
            rows.push("<td>" + $(this).find("REFERRAL_STATUS").text() + "</td>");
            rows.push("<td style='width: 12%; text-align: center'><a href='javascript:loadFunctionPages(\"PostReleaseServicesReferral.aspx\", \"" + $(this).find("PRS_ID").text() + "\");'><img id='EditPRS_" + $(this).find("PRS_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
            rows.push("<td>&nbsp;</td>");
            rows.push("</tr>");
            i++;
        });
        var top = "<table style='margin: 0px auto;width: 100%'>";
        var bottom = "</table>";
        var table = top + headers.join("") + rows.join("") + bottom;
        $("#sp" + infoType).empty().html(table);
    }
    else {
        headers.push("<tr style='background-color: #6699cc; color: white'>");
        headers.push("<th style='width: 12%'>Date Completed</td>");
        headers.push("<th style='width: 10%'>Last Updated</td>");
        headers.push("<th style='width: 40%'>Program Name</td>");
        headers.push("<th style='width: 14%'>Staff</td>");
        headers.push("<th colspan='4' style='width: 12%; text-align: center'>Options</td>");
        headers.push("<th stype='width: 12%'>&nbsp;</td>");
        headers.push("</tr>");
        // rows section
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if (i % 2 == 0) {
                rows.push("<tr style='background-color: #ccffff'>");
            }
            else {
                rows.push("<tr>");
            }

            rows.push("<td>" + $(this).find("DATE_COMPLETED").text() + "</td>");
            rows.push("<td>" + $(this).find("LAST_UPDATED").text() + "</td>");
            rows.push("<td>" + $(this).find("PROGRAM_NAME").text() + "</td>");
            rows.push("<td>" + $(this).find("STAFF").text() + "</td>");
            if (infoType == "KYR") {
                rows.push("<td style='width: 4%'><a href='KnowYourRight.aspx?EFFORT_ID=" + $(this).find("EFFORT_ID").text() + "'><img src='Images/edit.gif' border='0'></a></td>");
            }
            else if (infoType == "SIR") {
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"SIR.aspx\", \"" + $(this).find("SIR_ID").text() + "\");'><img src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"SIR\",\"" + $(this).find('SIR_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("SIR_ID").text() + "\", \"SignificantIncidentReport\");'><img src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "DischargeNotification") {
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"DischargeNotification.aspx\", \"" + $(this).find("DISCHARGE_ID").text() + "\");'><img id='EditDN_" + $(this).find("DISCHARGE_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='D" + i + "' href='JavaScript: deleteRecord(\"DischargeNotification\",\"" + $(this).find('DISCHARGE_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td ><a href='javascript:loadFunctionPages(\"DischargeDetail.aspx\", \"" + $(this).find("DISCHARGE_ID").text() + "\", \"DischargeNotification\");'><img id='PDFDN_" + $(this).find("DISCHARGE_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "Transfer") {
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"UACTransfer.aspx\", \"" + $(this).find("TRANSFER_REQUEST_ID").text() + "\");'><img id='EditTransfer_" + $(this).find("TRANSFER_REQUEST_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td style='width: 4%'><a id='T" + i + "' href='JavaScript: deleteTransferRecord(\"Transfer\",\"" + $(this).find('TRANSFER_REQUEST_ID').text() + "\", ua_gender, \"" + $(this).find('PROPOSED_PROGRAM_ID').text() + "\",ua_programId, ua_status);'><img id='PDFTransfer_" + $(this).find("REANSFER_REQUEST_ID").text() + "' src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td ><a href='javascript:loadFunctionPages(\"DischargeDetail.aspx\", \"" + $(this).find("TRANSFER_REQUEST_ID").text() + "\", \"TransferRequest\");'><img src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "ServicePlan") {
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"ISP.aspx\", \"" + $(this).find("ISP_ID").text() + "\");'><img src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='SP" + i + "' href='JavaScript: deleteRecord(\"ServicePlan\",\"" + $(this).find('ISP_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("ISP_ID").text() + "\", \"ISP\");'><img src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "DCS") {
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"UACAssessment.aspx\",\"" + $(this).find("UAC_ASSESSMENT_ID").text() + "\");'><img id='EditUACASSESSMENT_" + $(this).find("UAC_ASSESSMENT_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='DCS" + i + "' href='JavaScript: deleteRecord(\"DCS\",\"" + $(this).find('UAC_ASSESSMENT_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("UAC_ASSESSMENT_ID").text() + "\",\"UACAssessment\");'><img id='PDFUACASSESSMENT_" + $(this).find("UAC_ASSESSMENT_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "ARNotification") {
                rows.push("<td style='width: 4%'><a id='ARN" + i + "' href='AdvancedReleaseNotification.aspx?AR_NOTIFICATION_ID=" + $(this).find("AR_NOTIFICATION_ID").text() + "'><img src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td style='width: 4%'><img src='Images/delete.gif'></td>");
                }
            }
            else if (infoType == "MedicalExam") {
                rows.push("<td style='width: 4%'><a id='ME" + i + "' href='javascript:loadFunctionPages(\"Medical.aspx\", \"" + $(this).find("SCREENING_ID").text() + "\");'><img src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"MedicalExam\",\"" + $(this).find('SCREENING_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'>&nbsp;</td>");
                rows.push("<td>&nbsp;</td>");
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("SCREENING_ID").text() + "\", \"Medical\");'><img src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "NewAssessment") {
                rows.push("<td style='width: 4%'><a id='NA" + i + "' href='javascript:loadFunctionPages(\"UACInitialAssessment.aspx\", \"" + $(this).find("INITIAL_INTAKES_ID").text() + "\");'><img id='EditINITIALASSESSMENT_" + $(this).find("INITIAL_INTAKES_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"NewAssessment\",\"" + $(this).find('INITIAL_INTAKES_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\",\"" + $(this).find("INITIAL_INTAKES_ID").text() + "\",\"NewAssessment\");'><img id='PDFINITIALASSESSMENT_" + $(this).find("INITIAL_INTAKES_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "RiskAssessment") {
                rows.push("<td style='width: 4%'><a id='NA" + i + "' href='javascript:loadFunctionPages(\"UACRiskAssessment.aspx\", \"" + $(this).find("RISK_ASSESSMENT_ID").text() + "\");'><img id='EditRISKASSESSMENT_" + $(this).find("RISK_ASSESSMENT_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"RiskAssessment\",\"" + $(this).find('RISK_ASSESSMENT_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\",\"" + $(this).find("RISK_ASSESSMENT_ID").text() + "\",\"RiskAssessment\");'><img id='PDFINITIALASSESSMENT_" + $(this).find("INITIAL_INTAKES_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "TravelRequest") {
                rows.push("<td style='width: 4%'><a id='TR" + i + "' href='javascript:loadFunctionPages(\"TravelRequest_FosterCare.aspx\", \"" + $(this).find("TRAVEL_REQUEST_ID").text() + "\");'><img id='EditTravelRequest_" + $(this).find("TRAVEL_REQUEST_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"TravelRequest\",\"" + $(this).find('TRAVEL_REQUEST_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("TRAVEL_REQUEST_ID").text() + "\", \"TravelRequest_FosterCare\");'><img id='PDFTravelRequest_" + $(this).find("TRAVEL_REQUEST_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "CaseReview") {
                rows.push("<td style='width: 4%'><a id='CR" + i + "' href='javascript:loadFunctionPages(\"UACCaseReview_v2.aspx\", \"" + $(this).find("UAC_CASE_REVIEW_ID").text() + "\");'><img id='EditCaseReview_" + $(this).find("UAC_CASE_REVIEW_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"CaseReview\",\"" + $(this).find('UAC_CASE_REVIEW_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("UAC_CASE_REVIEW_ID").text() + "\", \"CaseReview\");'><img id='PDFCaseReview_" + $(this).find("UAC_CASE_REVIEW_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            else if (infoType == "SecureReview") {
                rows.push("<td style='width: 4%'><a id='CR" + i + "' href='javascript:loadFunctionPages(\"SecureReview.aspx\", \"" + $(this).find("SECURE_REVIEW_ID").text() + "\");'><img id='EditSecureReview_" + $(this).find("SECURE_REVIEW_ID").text() + "' src='Images/edit.gif' border='0'></a></td>");
                if ($("#hdnUserPrivilege").val() == "ReadOnly") {
                    //rows.push("<td>&nbsp;</td>");
                }
                else {
                    rows.push("<td><a id='S" + i + "' href='JavaScript: deleteRecord(\"SecureReview\",\"" + $(this).find('SECURE_REVIEW_ID').text() + "\");'><img src='Images/delete.gif' border='0'></a></td>");
                }
                rows.push("<td style='width: 4%'><a href='javascript:loadFunctionPages(\"CaseMgtDetail.aspx\", \"" + $(this).find("SECURE_REVIEW_ID").text() + "\", \"SecureReview\");'><img id='PDFSecureReview_" + $(this).find("SECURE_REVIEW_ID").text() + "' src='Images/pdf.gif' border='0'></a></td>");
            }
            rows.push("<td>&nbsp;</td>");
            rows.push("</tr>");
            i++;
        });
        var top = "<table style='margin: 0px auto;width: 100%'>";
        var bottom = "</table>";
        var table = top + headers.join("") + rows.join("") + bottom;
        $("#sp" + infoType).empty().html(table);
    }
}
function PopulateReports(rptType) {
    $(document).ready(function () {
        $("#trTransfer").hide();
        $("#trMedical").hide();
        $("#trPlacement").hide();
        $("#trPlacement_Authorization").hide();
        $("#trRelease_Verification").hide();
        $("#trORR_NOTICE_TO_ICE_CCRUACSRCA").hide();
        $("#trORR_DCS_Transfer_Request").hide();
        $("#trORR_Notice_of_Transfer_to_ICE").hide();

        var imgSrc = $("#img" + rptType).attr('src');
        var UACId = $("#hdnUACProgId").val();
        if (imgSrc == 'Images/plus.gif') {
            $("#img" + rptType).attr('src', 'Images/minus.gif');
            $('#sp' + rptType).empty().append('<img src="Images/loader03.gif" style="width: 16px; height: 16px" id="imgLoader">');
            $('#sp' + rptType).append('&nbsp;&nbsp;Loading ...');
            $('#hdnInfoType').val(rptType);

            $.ajax({
                type: "POST",
                url: "UACWebServices.asmx/getReportInfo",
                data: '{UAC_ID: ' + UACId + ', infoType: "' + rptType + '"}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: OnRptInfoPopulated,
                failure: function (data) {
                    alert(data.d);
                }
            });
        }
        else if (imgSrc == 'Images/minus.gif') {
            $("#img" + rptType).attr('src', 'Images/plus.gif');
            $('#sp' + rptType).empty();
        }
    });
}
function OnRptInfoPopulated(response) {
    var infoType = $('#hdnInfoType').val();
    $('#sp' + infoType).empty();
    var xmlDoc = $.parseXML(response.d);
    var xml = $(xmlDoc);
    var uacInfo = xml.find("Table");
    var i = 1;
    var color = "white";
    $.each(uacInfo, function () {
        var uacInfo = $(this);

        if ($(this).find("HASREPORT").text() == "1") {
            if (i % 2 == 0) {
                color = "#ccffff";
            }
            else {
                color = "white";
            }
            switch ($(this).find("RPTTYPE").text()) {
                case "Transfer":
                    $("#trTransfer").show();
                    $("#trTransfer").css("background-color", color);
                    break;
                case "Medical":
                    $("#trMedical").show();
                    $("#trMedical").css("background-color", color);
                    break;
                case "Placement":
                    $("#trPlacement").show();
                    $("#trPlacement").css("background-color", color);
                    break;
                case "Placement_Authorization":
                    $("#trPlacement_Authorization").show();
                    $("#trPlacement").css("background-color", color);
                    break;
                case "Release_Verification":
                    $("#trRelease_Verification").show();
                    $("#trRelease_Verification").css("background-color", color);
                    break;
                case "ORR_NOTICE_TO_ICE_CCRUACSRCA":
                    $("#trORR_NOTICE_TO_ICE_CCRUACSRCA").show();
                    $("#trORR_NOTICE_TO_ICE_CCRUACSRCA").css("background-color", color);
                    break;
                case "ORR_DCS_Transfer_Request":
                    $("#trORR_DCS_Transfer_Request").show();
                    $("#trORR_DCS_Transfer_Request").css("background-color", color);
                    break;
                case "ORR_Notice_of_Transfer_to_ICE":
                    $("#trORR_Notice_of_Transfer_to_ICE").show();
                    $("#trORR_Notice_of_Transfer_to_ICE").css("background-color", color);
                    break;
            }
            i++;
        }
    });
    //$("#tblRpt tr:odd").css("background-color", "white");
    //$("#tblRpt tr:even").css("background-color", "#ccffff");
}

function checkUserId() {
    $(document).ready(function () {
        var userId = $('#hdnUserId').val();
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/checkUserId",
            data: '{userId: "' + $('#' + userId).val() + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                if (data.d == 'false') {
                    alert('The user id is used. Please choose different one.');
                }
            },
            failure: function (response) {
                alert(response.d);
            }
        });
    });
}
function checkPassword() {
    $(document).ready(function () {
        var pwd = $('#txtCurrPassword').val();
        var usrId = "";
        if ($("#LabelUID").is("input:text")) {
            usrId = $("#LabelUID").val();
        }
        else {
            usrId = $("#LabelUID").text();
        }
        //if (!usrId || usrId == 'undefined') {
        //    usrId = $("#LableUID").val();
        //}
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/checkPasswordByUserID",
            data: '{userId:"' + usrId + '", pwd: "' + pwd + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                if (data.d == 'false') {
                    alert('The current Password is not correct.');
                    $("#txtCurrPassword").val("");
                }
            },
            failure: function (response) {
                alert(response.d);
            }
        });
    });
}
function checkSponsorDOB() {
    $(document).ready(function () {
        var spId = $('#hdnSponsorId').val();
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/getSponsorInfo",
            data: '{sponsorId: ' + $('#' + spId).val() + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var xmlDoc = $.parseXML(data.d);
                var xml = $(xmlDoc);
                var spInfo = xml.find("Table");
                $.each(spInfo, function () {
                    var spInfo = $(this);
                    var strDate = $(this).find("DOB").text();
                    if (strDate.length > 0) {
                        $('#ContentPlaceHolder1_spSponsorDOB').text($.date(strDate));
                    }
                    else {
                        $('#ContentPlaceHolder1_spSponsorDOB').text('');
                    }
                    $('#ContentPlaceHolder1_spRelationship').text($(this).find('RELATIONSHIP').text());
                });
            },
            failure: function (data) {
                alert(data.d);
            }
        });
    });
}
$.date = function (dateObject) {
    if (dateObject) {
        if (typeof dateObject == 'undefined' || dateObject == null || dateObject == "") {
            return "";
        }
        var d = new Date(dateObject);
        var day = d.getDate();
        var month = d.getMonth() + 1;
        var year = d.getFullYear();
        if (day < 10) {
            day = "0" + day;
        }
        if (month < 10) {
            month = "0" + month;
        }
        var date = month + "/" + day + "/" + year;

        return date;
    }
    return "";
}

function getSponsorInfo() {
    $(document).ready(function () {
        var spId = '';
        if ($('hdnSponsorId').length) {
            spId = $('#hdnSponsorId').val();
        }
        else {
            spId = 'hdnSponsorID';
        }
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/getSponsorInfo",
            data: '{sponsorId: ' + $('#' + spId).val() + ', uacId: ' + $('#hdnUACID').val() + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                var xmlDoc = $.parseXML(data.d);
                var xml = $(xmlDoc);
                var spInfo = xml.find("Table");
                if ($('#ContentPlaceHolder1_spSponsorDOB').length) {
                    $.each(spInfo, function () {
                        var spInfo = $(this);
                        var strDate = $(this).find("DOB").text();
                        if (strDate.length > 0) {
                            $('#ContentPlaceHolder1_spSponsorDOB').text($.date(strDate));
                        }
                        else {
                            $('#ContentPlaceHolder1_spSponsorDOB').text('');
                        }
                    });
                }
                if ($('#ContentPlaceHolder1_spRelationship').length) {
                    $('#ContentPlaceHolder1_spRelationship').text($(this).find('RELATIONSHIP').text());
                }
            },
            failure: function (data) {
                alert(data.d);
            }
        });
    });
}

function getSponsorCategory(obj) {
    $(document).ready(function () {
        if (!$(obj).val()) {
            if ($('#lblSponsorCategory').length) {
                $('#lblSponsorCategory').text('Category 4');
            }
            return;
        }
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/getSponsorCategory",
            data: '{rId: ' + $('#' + $(obj).attr('id')).val() + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                if ($('#lblSponsorCategory').length) {
                    $('#lblSponsorCategory').text('Category ' + data.d.toString());
                }
            },
            failure: function (data) {
                alert(data.d);
            }
        });
    });
}

function PopulateProgram(hdnId, obj) {
    $(document).ready(function () {
        var cntrId = $('#' + hdnId).val();
        $('#' + cntrId).attr("disabled", "disabled");
        $('#' + cntrId).empty().append('<option selected="selected" value="0">Loading...</option>');
        $('#hdnCurrControl').val(cntrId);
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/programList",
            data: '{progTypeId: ' + obj.value + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: PopulateControl,
            failure: function (data) {
                alert(data.d);
            }
        });
    });
}
function PopulateControl(response) {
    $(document).ready(function () {
        var control = $('#' + $('#hdnCurrControl').val());
        var list = response.d;
        if (list.length > 0) {
            control.removeAttr("disabled");
            control.empty().append('<option selected="selected" value="0">Select Program</option>');
            $.each(list, function () {
                control.append($("<option></option>").val(this['Value']).html(this['Text']));
            });
        }
        else {
            control.empty().append('<option selected="selected" value="0">No disponible<option>');
        }
    });
}
var wrongFileExt = false;
function uploadComplete(sender) {
    $("#imgLoader").hide();
}
function uploadError(sender) {
    $("#imgLoader").hide();
    $("#spErrMsg").empty().append("File upload failed.");
    $("#spErrMsg").attr('style', 'color:red');
}
function uploadStart(sender) {
    $("#spErrMsg").empty();
    $("#imgLoader").show();
}
function uploadCompleteIntakeFile(sender) {
    $("#imgLoader").hide();
    if (wrongFileExt) {
        $(".uploadFile").find("input[type='text']").css("background-color", "red")
    }

}
function uploadStartIntakeFile(sender, e) {
    var fileName = e.get_fileName();
    var fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1);
    wrongFileExt = false;
    if (fileExtension === 'zip') {
        $("#spErrMsg").empty();
        $("#imgLoader").show();
        $(".uploadFileBtn").attr('disabled', false);
    }
    else {
        wrongFileExt = true;
        $(".uploadFileBtn").attr('disabled', true);
        $("#spErrMsg").empty().append("Only zip files that contain encrypted XML are accepted, all other files shall be rejected");
        $("#spErrMsg").attr('style', 'color:red');
        sender._stopLoad(fileName);
    }
}
function uploadErrorIntakeFile(sender, e) {
    var error = e.get_errorMessage();
    $(".uploadFileBtn").attr('disabled', true);
    $("#imgLoader").hide();
    $("#spErrMsg").empty().append(error);
    $("#spErrMsg").attr('style', 'color:red');
}

function uploadCPSComplete(sender) {
    $("#imgCPSLoader").hide();
}
function uploadCPSError(sender) {
    $("#imgCPSLoader").hide();
    $("#spCPSErrMsg").empty().append("File upload failed.");
    $("#spCPSErrMsg").attr('style', 'color:red');
}
function uploadCPSStart(sender) {
    $("#spCPSErrMsg").empty();
    $("#imgCPSLoader").show();
}
function uploadLLEComplete(sender) {
    $("#imgLLELoader").hide();
}
function uploadLLEError(sender) {
    $("#imgLLELoader").hide();
    $("#spLLEErrMsg").empty().append("File upload failed.");
    $("#spLLEErrMsg").attr('style', 'color:red');
}
function uploadLLEStart(sender) {
    $("#spLLEErrMsg").empty();
    $("#imgLLELoader").show();
}
function uploadDOJComplete(sender) {
    $("#imgDOJLoader").hide();
}
function uploadDOJError(sender) {
    $("#imgDOJLoader").hide();
    $("#spDOJErrMsg").empty().append("File upload failed.");
    $("#spDOJErrMsg").attr('style', 'color:red');
}
function uploadDOJStart(sender) {
    $("#spDOJErrMsg").empty();
    $("#imgDOJLoader").show();
}
function uploadCPSSAComplete(sender) {
    $("#imgCPSSALoader").hide();
}
function uploadCPSSAError(sender) {
    $("#imgCPSSALoader").hide();
    $("#spCPSSAErrMsg").empty().append("File upload failed.");
    $("#spCPSSAErrMsg").attr('style', 'color:red');
}
function uploadCPSSAStart(sender) {
    $("#spCPSSAErrMsg").empty();
    $("#imgCPSSALoader").show();
}
function uploadCActionComplete(sender) {
    $("#imgCActionLoader").hide();
}
function uploadCActionError(sender) {
    $("#imgCActionLoader").hide();
    $("#spCActionErrMsg").empty().append("File upload failed.");
    $("#spCActionErrMsg").attr('style', 'color:red');
}
function uploadCActionStart(sender) {
    $("#spCActionErrMsg").empty();
    $("#imgCActionLoader").show();
}
function uploadSLInfoComplete(sender) {
    $("#imgSLInfoLoader").hide();
}
function uploadSLInfoError(sender) {
    $("#imgSLInfoLoader").hide();
    $("#spSLInfoErrMsg").empty().append("File upload failed.");
    $("#spSLInfoErrMsg").attr('style', 'color:red');
}
function uploadSLInfoStart(sender) {
    $("#spSLInfoErrMsg").empty();
    $("#imgSLInfoLoader").show();
}

function releaseTypeChange(obj) {
    var radio = obj.getElementsByTagName("input");
    var n = 0;
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked) {
            n = i;
            break;
        }
    }
    if (n == 0) {
        $('#tdSponsorInfo').show();
        $('#tdProgInfo').hide();

    }
    else {
        $('#tdSponsorInfo').hide();
        $('#tdProgInfo').show();
    }
}

function changeHC(obj) {
    var GetValue = $('#' + obj.id).find(":checked").val();
    if (eval(GetValue) == 1) {
        $('#thMedInfo').show();
    }
    else {
        $('#thMedInfo').hide();
    }
}
function changeCC(obj) {
    var GetValue = $('#' + obj.id).find(":checked").val();
    if (eval(GetValue) == 1) {
        $('#thSSS').show();
    }
    else {
        $('#thSSS').hide();
    }
}
function checkANumber(obj) {
    $(document).ready(function () {
        var aNo = obj.value;
        $.ajax({
            type: "POST",
            url: "UACWebServices.asmx/checkANumber",
            data: '{aNumber: "' + aNo + '"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: reloadUserInfo,
            failure: function (response) {
                alert(response.d);
            }
        });
    });
}
function reloadUserInfo(response) {
    $(document).ready(function () {
        var xmlDoc = $.parseXML(response.d);
        var xml = $(xmlDoc);
        var uacInfo = xml.find("Table");
        var i = 1;
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if ($(this).find("FIRST_NAME").text()) {
                var strTbl = "<table><tr><td rowspan='5' style='vertical-align: top; padding-top: 10px'><img src='Images/question.gif' bordor='0'></td><td colspan='2'>This Alien Number is in the system. <b>The current/latest status is:</b>"
                    + "<tr><th>Name:</th><th style='color: red'>" + $(this).find("FIRST_NAME").text() + " " + $(this).find("LAST_NAME").text() + "</th></tr>"
                    + "<tr><th>Status:</th><th style='color: red'>" + $(this).find("UAC_STATUS").text() + "</th></tr>"
                    + "<tr><th>Program:</th><th style='color: red'>" + $(this).find("PROGRAM_NAME").text() + "</th></tr>"
                    + "<tr><td colspan='2'>Do you want to pull UAC information for this number?</td></tr>"
                    + "</table>";
                $.prompt(strTbl, {
                    title: "<span style='color:red'>Warning!</span>",
                    buttons: { "Yes": true, "No": false },
                    submit: function (e, v, m, f) {
                        // use e.preventDefault() to prevent closing when needed or return false. 
                        // e.preventDefault(); 
                        //console.log("Value clicked was: " + v);
                        if (v == true) {
                            $.each(uacInfo, function () {
                                var uacInfo = $(this);
                                $('#ContentPlaceHolder1_txtFirstName').val($(this).find("FIRST_NAME").text());
                                $('#ContentPlaceHolder1_txtLastName').val($(this).find("LAST_NAME").text());
                                $('#ContentPlaceHolder1_txtAKA').val($(this).find("AKA").text());
                                $('#ContentPlaceHolder1_txtDOB').val($.date($(this).find("DOB").text()));
                                $('#ContentPlaceHolder1_ddGender').val($(this).find("GENDER").text());
                                $('#ContentPlaceHolder1_ddCountry').val($(this).find("COB").text());
                            });
                        }
                        else {
                            $('#ContentPlaceHolder1_txtFirstName').val('');
                            $('#ContentPlaceHolder1_txtLastName').val('');
                            $('#ContentPlaceHolder1_txtAKA').val('');
                            $('#ContentPlaceHolder1_txtDOB').val('');
                            $('#ContentPlaceHolder1_ddGender').val('');
                            $('#ContentPlaceHolder1_ddCountry').val('');
                        }
                    }
                });
            }
        });
    });
}

function checkProgram() {

    var proceed = false;
    if ($('select[id*="ddEnrolledProgram"] option:selected').index() > 0) {
        proceed = true;
    } else {
        alert("Please select a program first.");
        proceed = false;
    }
    if ($('#txtORRPD').val() === '' || $('#txtORRPT').val() === '') {
        alert("Please set ORR Placement Date/Time");
        proceed = false;
    }
    var dt1 = $('#txtORRPD').val() + " " + $('#txtORRPT').val();
    var dt2 = new Date(dt1);
    var dt3 = dt2.getTime();
    if (isNaN(dt3)) {
        alert("ORR Placement Date/Time is invalid");
        proceed = false;
    }
    //Make sure ORR Placement Date/TIme is not future date or more than 7 days in the past
    var d = new Date();
    var maxDate = $.date(d);
    if (new Date(maxDate).getTime() < new Date($('#txtORRPD').val()).getTime()) {
        alert("ORR Placement Date/Time cannot be a future date");
        proceed = false;
    }
    var d2 = new Date();
    d2.setDate(d2.getDate() - 7);
    var newDate = d2.toInputFormat();
    if (new Date($('#txtORRPD').val()).getTime() < new Date(newDate).getTime()) {
        alert("ORR Placement Date cannot be more than 7 days in the past.");
        proceed = false;
    }

    if (proceed && $('.itemChkBox :checked').length === 0) {
        alert("Please select a at least one UC.");
        proceed = false;
    }
    return proceed;
}


function validateIntake() {

    if (Page_ClientValidate()) {
        var msg = "";

        if (new Date($("#txtORRPD").val()) < new Date($("#txtReferralDate").val())) {
            msg += "ORR Placement Date cannot be earlier than Referral Date.";
        }

        if ($("#txtORRPD").val() == "" && ($("#ddProgramType").val() != "" && $("#ddProgramType").val() != "")) {
            msg += "ORR Placement Date cannot be empty if Program Type and Enroll in Program are selected.";
        }

        if (msg.length > 0) {
            alert(msg);
            return false;
        }
        return true;
    }
    return false;
}

function ValidateORRPD(oSrc, args) {
    if ($("#ddStatus").val() != "CANCELLED") {
        var dd = new Date(args.Value);
        if (isNaN(dd)) {
            oSrc.errormessage = "ORR Placement Date is required";
            args.IsValid = false;
            return;
        }
        if (new Date($("#hdnORRPDOrg").val()).getTime() != new Date(args.Value).getTime()) {
            if ($("#txtReferralDate").val() != "" && new Date(args.Value).getTime() < new Date($("#txtReferralDate").val()).getTime()) {
                oSrc.errormessage = "ORR Placement Date cannot be earlier than Referral Date.";
                args.IsValid = false;
                return;
            }

            var d = new Date();
            d.setDate(d.getDate() - 7);
            var newDate = d.toInputFormat();
            if (new Date(args.Value).getTime() < new Date(newDate).getTime()) {
                oSrc.errormessage = "ORR Placement Date cannot be more than 7 days in the past.";
                args.IsValid = false;
                return;
            }
        }
        oSrc.errormessage = "ORR Placement Date cannot be future date.";
        validateFutureDate(oSrc, args);
    }
}

function ValidateReferralDate(oSrc, args) {
    if ($("#ddStatus").val() != "CANCELLED") {
        if ($("#txtReferralDate").val() != "") {
            if ($("#txtReferralDateOrg").val() != "" && (new Date($("#txtReferralDateOrg").val()).getTime() != new Date($("#txtReferralDate").val()).getTime())) {
                if (new Date($("#txtORRPD").val()).getTime() < new Date($("#txtReferralDate").val()).getTime()) {
                    oSrc.errormessage = "Referral Date cannot later than ORR Placement Date.";
                    args.IsValid = false;
                    return;
                }
                if ($("#ddStatus").val() == "PENDING") {
                    var d = new Date();
                    d.setDate(d.getDate() - 7);
                    var newDate = d.toInputFormat();
                    if (new Date($("#txtReferralDate").val()).getTime() < new Date(newDate).getTime()) {
                        oSrc.errormessage = "Referral Date cannot be more than 7 days in the past.";
                        args.IsValid = false;
                        return;
                    }

                    oSrc.errormessage = "Referral Date cannot be future date.";
                    validateFutureDate(oSrc, args);
                }
            }
        }
    }
}

function ValidateReferralTime(oSrc, args) {
    if ($("#ddStatus").val() != "CANCELLED") {
        if ($("#txtReferralDate").val() != "" && !isNaN(args.Value)) {
            args.IsValid = false;
        }
    }
}

Date.prototype.toInputFormat = function () {
    var yyyy = this.getFullYear().toString();
    var mm = (this.getMonth() + 1).toString(); // getMonth() is zero-based
    var dd = this.getDate().toString();
    return yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]); // padding
}

function validateAdmission() {
    //    var strStatus = $('#hdnStatusId').val();
    //    var strDate = $('#hdnDate').val();
    //    var strTime = $('#hdnTime').val();
    //    var rbVerify = $('#hdnrbVerify').val();
    var msg = "";
    //    if ($("#ddStatus").val() == "") {
    //        alert("Please select UAC Status.");
    //        return false;
    //    }
    if ($("#ddStatus").val() == "ADMITTED") {
        if (!$("#txtAdmissionDate").val()) {
            msg += "Admission Date is required.\n";
        }
        if (!$("#txtAdmissionTime").val()) {
            msg += "Admission Time is required.\n";
        }
        if (!$("#rdVerified input:checked").val()) {
            msg += "Bio Verification is required.\n";
        }
        if (new Date($("#txtAdmissionDate").val()) > $.now()) {
            msg += "Admission Date cannot be future date.\n";
        }
        if (new Date($("#txtAdmissionDate").val()) < new Date($("#hdnORRPlacementDate").val())) {
            msg += "Admission Date cannot be earlier than ORR Placement Date.";
        }
        if (msg.length > 0) {
            alert(msg);
            return false;
        }
    }
    return true;
}
// Begin of Admission Page validation
function validateAdmissionDate(oSrc, args) {
    if ($("#ddStatus").val() == "ADMITTED") {
        var dd = new Date(args.Value);
        if (isNaN(dd)) {
            oSrc.errormessage = "Admission Date is required.";
            args.IsValid = false;
        }
        else {
            var d = new Date();
            //var currDate = $.date(d);
            d.setDate(d.getDate() - 2);
            var newDate = d.toInputFormat();
            if ($("#hdnAdmissionDateOrg").val() != "" && new Date($("#hdnAdmissionDateOrg").val()).getTime() != new Date(args.Value).getTime()) {
                if (new Date(args.Value).getTime() < new Date($("#hdnORRPlacementDate").val()).getTime()) {
                    oSrc.errormessage = "Admission Date cannot be earlier than ORR Placement Date.";
                    args.IsValid = false;
                    return;
                }
                if (new Date(args.Value).getTime() < new Date(newDate).getTime()) {
                    oSrc.errormessage = "Admitted Date cannot be earlier than 2 days.";
                    args.IsValid = false;
                    return;
                }
                oSrc.errormessage = "Admission date cannot be future date.";
                validateFutureDate(oSrc, args);
            }
            else if ($("#hdnAdmissionDateOrg").val() == "") {
                if (new Date(args.Value).getTime() < new Date(newDate).getTime()) {
                    oSrc.errormessage = "Admitted Date cannot be earlier than 2 days.";
                    args.IsValid = false;
                    return;
                }
                oSrc.errormessage = "Admission date cannot be future date.";
                validateFutureDate(oSrc, args);
            }
        }
    }
}

function validateAdmissionTime(oSrc, args) {
    if ($("#ddStatus").val() == "ADMITTED") {
        if (!isNaN(args.Value)) {
            oSrc.errormessage = "Admission time is required.";
            args.IsValid = false;
        }
    }
}

function validateBioverification(oSrc, args) {
    if ($("#ddStatus").val() == "ADMITTED") {
        if (!$("#rdVerified input:checked").val()) {
            oSrc.errormessage = "Bio verification is required.";
            args.IsValid = false;
        }
    }
}
// End of Admission Page validation 

function checkProgList() {
    var roleType = $('#hdnRoleType').val();
    if ($('#' + roleType).val() == "Program") { // || $('#' + roleType).val() == "ICE" || $('#' + roleType).val() == "CBP") {
        var progListId = $('#hdnProgList').val();

        var realvalues = [];
        $('#' + progListId + ' :selected').each(function (i, selected) {
            realvalues[i] = $(selected).val();
        });
        if (realvalues.length == 0) {
            if ($('#' + roleType).val() == "Program") {
                alert("Please select programs first.");
            }
            //            else if ($('#' + roleType).val() == "ICE") {
            //                alert("Please select ICE Office first.");
            //            }
            //            else if ($('#' + roleType).val() == "CBP") {
            //                alert("Please select CBP Border Patrol Station first.");
            //            }
            return false;
        }
        var uprId = $('#hdnUsrRight').val();
        if ($('#' + uprId).val() == "") {
            alert("Please select User Privelege.");
            return false;
        }
    }
    return true;
}

function successMsg(pageUrl) {
    alert('Infomation was saved successfully.');
    document.location.href = pageUrl;
}

function deleteTransferRecord(infoType, recId, gender, destinationProgramId, sourceProgramId, status) {
    $(document).ready(function () {
        if (confirm("Are you sure you want to delete this record?")) {
            $('#hdnInfoType').val(infoType);
            $.ajax({
                type: "POST",
                url: "UACWebServices.asmx/deleteTransferRecord",
                data: '{recordType: "' + infoType + '", strId: "'
                 + recId + '", gender: "' + gender + '", uac_programid: "'
                 + $("#hdnUACProgId").val() + '", gender: "' + gender
                  + '", sourceProgramId: "' + sourceProgramId
                   + '", destinationProgramId: "' + destinationProgramId + '", status: "'
                  + status + '"}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (res) {
                    // repopulateData(res);
                    window.location.reload();
                },
                failure: function (data) {
                    alert(data.d);
                }
            });
        }
    });
}

function deleteRecord(infoType, recId) {
    $(document).ready(function () {
        if (confirm("Are you sure you want to delete this record?")) {
            $('#hdnInfoType').val(infoType);
            $.ajax({
                type: "POST",
                url: "UACWebServices.asmx/deleteRecord",
                data: '{recordType: "' + infoType + '", strId: "' + recId + '"}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: repopulateData,
                failure: function (data) {
                    alert(data.d);
                }
            });
        }
    });
}

function repopulateData(response) {
    $(document).ready(function () {
        var xmlDoc = $.parseXML(response.d);
        var xml = $(xmlDoc);
        var uacInfo = xml.find("Table");
        $.each(uacInfo, function () {
            var uacInfo = $(this);
            if ($(this).find("RETURNVAL").text() == "OK") {
                var infoType = $('#hdnInfoType').val();
                $("#img" + infoType).attr('src', 'Images/plus.gif');

                loadFunctionPages( "CaseMgtDetail.aspx", "", "" );
                //location.href = location.href; //.reload();
                //PopulateUACInfo( infoType );
            }
            else {
                alert("Error happened when deleting the record.");
            }
        });
    });
}

function checkConfirm(obj)
{
    var curr_Id = "";
    if ($(obj).attr("id").indexOf("txtComments") > -1) {
        curr_Id = "txtComments";
    }
    else if ($(obj).attr("id").indexOf("chkVerified") > -1) {
        curr_Id = "chkVerified";
    }

    var VER = $(obj).attr("id").replace(curr_Id, "chkVerified");
    var COM = $(obj).attr("id").replace(curr_Id, "txtComments");   
    var tempVerified = "";
    var tempComment = "";
    var UM_Id = $(obj).attr("id").replace(curr_Id, "txtBedsUnavailableM");
    var UF_Id = $(obj).attr("id").replace(curr_Id, "txtBedsUnavailableF");

    tempComment = $('#' + COM).val().trim();
    tempVerified = ($('#' + VER).is(":checked"));
    if (document.getElementById("hdnRole").value == "Program") {
        if (document.getElementById(UM_Id).oldvalue != undefined) {
            if (document.getElementById(UM_Id).oldvalue != $('#' + UM_Id).val() || document.getElementById(UF_Id).oldvalue != $('#' + UF_Id).val()) {
                if ((tempComment && tempComment != undefined && tempComment != "" && tempComment.length != 0) && tempVerified)
                    document.getElementById("btnConfirm").disabled = false;
                else
                    document.getElementById("btnConfirm").disabled = true;
            }
        }
        else {
            if ((!tempComment || tempComment == undefined || tempComment == "" || tempComment.length == 0) && !tempVerified) {
                document.getElementById("btnConfirm").disabled = true;
            }
            else
                document.getElementById("btnConfirm").disabled = false;
        }
    }
    if (document.getElementById("hdnRole").value == "HQ")
        document.getElementById("btnConfirm").disabled = false;
}

function checkCapacity(obj) {
    var curr_Id = "";
    if ($(obj).attr("id").indexOf("txtInCareM") > -1) {
        curr_Id = "txtInCareM";
    }
    else if ($(obj).attr("id").indexOf("txtInCareF") > -1) {
        curr_Id = "txtInCareF";
    }
    else if ($(obj).attr("id").indexOf("txtBedsInReserveM") > -1) {
        curr_Id = "txtBedsInReserveM";
    }
    else if ($(obj).attr("id").indexOf("txtBedsInReserveF") > -1) {
        curr_Id = "txtBedsInReserveF";
    }
    else if ($(obj).attr("id").indexOf("txtBedsUnavailableM") > -1) {
        curr_Id = "txtBedsUnavailableM";
    }
    else if ($(obj).attr("id").indexOf("txtBedsUnavailableF") > -1) {
        curr_Id = "txtBedsUnavailableF";
    }
    else if ($(obj).attr("id").indexOf("txtFundedCapacityM") > -1) {
        curr_Id = "txtFundedCapacityM";
    }
    else if ($(obj).attr("id").indexOf("txtFundedCapacityF") > -1) {
        curr_Id = "txtFundedCapacityF";
    }
    else if ($(obj).attr("id").indexOf("txtComments") > -1) {
        curr_Id = "txtComments";
    }
    else if ($(obj).attr("id").indexOf("txtInstructions") > -1) {
        curr_id = "txtInstructions";
    }
    var CM_Id = $(obj).attr("id").replace(curr_Id, "txtInCareM");
    var CF_Id = $(obj).attr("id").replace(curr_Id, "txtInCareF");   
    var TT_Id = $(obj).attr("id").replace(curr_Id, "txtTotal");
    var RM_Id = $(obj).attr("id").replace(curr_Id, "txtBedsInReserveM");
    var RF_Id = $(obj).attr("id").replace(curr_Id, "txtBedsInReserveF");
    var RT_Id = $(obj).attr("id").replace(curr_Id, "txtBedsInReserveT");
    var UM_Id = $(obj).attr("id").replace(curr_Id, "txtBedsUnavailableM");
    var UF_Id = $(obj).attr("id").replace(curr_Id, "txtBedsUnavailableF");
    var UT_Id = $(obj).attr("id").replace(curr_Id, "txtBedsUnavailableT");
    var FM_Id = $(obj).attr("id").replace(curr_Id, "txtFundedCapacityM");
    var FF_Id = $(obj).attr("id").replace(curr_Id, "txtFundedCapacityF");
    var FT_Id = $(obj).attr("id").replace(curr_Id, "txtFundedCapacityT");
    var RC_Id = $(obj).attr("id").replace(curr_Id, "txtReconcile");
    var rowStatus = $(obj).attr("id").replace(curr_Id, "txtRowStatus");
    var IM_Id = $(obj).attr("id").replace(curr_Id, "txtInTransferM");
    var IF_Id = $(obj).attr("id").replace(curr_Id, "txtInTransferF");
    var EM_Id = $(obj).attr("id").replace(curr_Id, "txtEnrouteM");
    var EF_Id = $(obj).attr("id").replace(curr_Id, "txtEnrouteF");
    var Type_Id = $(obj).attr("id").replace(curr_Id, "lblType");
    var temp = '';
    //            test = document.getElementById(Type_Id).textContent;

    //    if (parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)) > parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0))) {
    //        alert("Beds Unavailable cannot exceed Beds in Reserve");
    //        return false;
    //    }
    //    else if (parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)) > parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0))) {
    //        alert("Beds Unavailable cannot exceed Beds in Reserve");
    //        return false;
    //    }


    if (curr_Id != "txtComments" && curr_Id != "txtInstructions") {
        if (curr_Id == "txtInCareM" || curr_Id == "txtInCareF") {           
            $('#' + TT_Id).val(parseInt(iif($.isNumeric($('#' + EM_Id).val()), $('#' + EM_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + EF_Id).val()), $('#' + EF_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + IM_Id).val()), $('#' + IM_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + IF_Id).val()), $('#' + IF_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + CM_Id).val()), $('#' + CM_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + CF_Id).val()), $('#' + CF_Id).val(), 0)));
        }
        else if (curr_Id == "txtBedsInReserveM") {           
            
            if (document.getElementById("hdnRole").value == "Program") {     //For program staff
                
                    temp = parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0))
                                - parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0))
                                + parseInt(document.getElementById(RM_Id).oldvalue);

                    if (temp < 0) {
                        alert("Funded Capacity has been exceeded.");
                        $('#' + RM_Id).val(document.getElementById(RM_Id).oldvalue);
                    }
                    else {
                        $('#' + RF_Id).val(temp);
                        temp = parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) - document.getElementById(RM_Id).oldvalue;
                        $('#' + FM_Id).val(parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0)) + temp);
                        $('#' + FF_Id).val(parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0)) - temp);

                        if (parseInt(iif($.isNumeric($('#' + RC_Id).val()), $('#' + RC_Id).val(), 0)) > 0) {  //check for Reconcile
                            if (((parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)))
                           + (parseInt(iif($.isNumeric($('#' + IM_Id).val()), $('#' + IM_Id).val(), 0)))
                           + (parseInt(iif($.isNumeric($('#' + EM_Id).val()), $('#' + EM_Id).val(), 0)))
                           + (parseInt(iif($.isNumeric($('#' + CM_Id).val()), $('#' + CM_Id).val(), 0)))
                           + (parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)))) > (parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0))))
                            {
                                $('#' + RM_Id).val(document.getElementById(RM_Id).oldvalue);                                                          
                                alert("Funded Capacity has been exceeded.");
                            }
                        }
                    }
            }           
            else {   //For other users except program staff
                if (((parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + IM_Id).val()), $('#' + IM_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + EM_Id).val()), $('#' + EM_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + CM_Id).val()), $('#' + CM_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)))) > (parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0)))) {
                    $('#' + RM_Id).val(document.getElementById(RM_Id).oldvalue);
                    $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));                
                    alert("Funded Capacity has been exceeded.");
                }
            }
            $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));
        }
        else if (curr_Id == "txtBedsInReserveF") {
            $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));

            if (document.getElementById("hdnRole").value == "Program") {            //For program staff

                temp = parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0))
                               - parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0))
                               + parseInt(document.getElementById(RF_Id).oldvalue);
                if (temp < 0) {
                    alert("Funded Capacity has been exceeded.");
                    $('#' + RF_Id).val(document.getElementById(RF_Id).oldvalue);
                }
                else {
                    $('#' + RM_Id).val(temp);
                    temp = parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)) - document.getElementById(RF_Id).oldvalue;
                    $('#' + FM_Id).val(parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0)) - temp);
                    $('#' + FF_Id).val(parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0)) + temp);                                      
                   
                    if (parseInt(iif($.isNumeric($('#' + RC_Id).val()), $('#' + RC_Id).val(), 0)) > 0) {    //Check for Reconcile
                        if (((parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)))
                        + (parseInt(iif($.isNumeric($('#' + IF_Id).val()), $('#' + IF_Id).val(), 0)))
                        + (parseInt(iif($.isNumeric($('#' + EF_Id).val()), $('#' + EF_Id).val(), 0)))
                        + (parseInt(iif($.isNumeric($('#' + CF_Id).val()), $('#' + CF_Id).val(), 0)))
                        + (parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)))) > (parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0))))
                        {
                            $('#' + RF_Id).val(document.getElementById(RF_Id).oldvalue);
                            $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));
                            alert("Funded Capacity has been exceeded.");
                        }
                    }
                }
            }
            else {      //For other users except program staff
                if (((parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + IF_Id).val()), $('#' + IF_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + EF_Id).val()), $('#' + EF_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + CF_Id).val()), $('#' + CF_Id).val(), 0)))
                    + (parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)))) > (parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0)))) {
                    $('#' + RF_Id).val(document.getElementById(RF_Id).oldvalue);
                    $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));                 
                    alert("Funded Capacity has been exceeded.");
                }
            }
        }
        else if (curr_Id == "txtBedsUnavailableM") {

            if (document.getElementById("hdnRole").value == "HQ")
                document.getElementById("btnConfirm").disabled = false;

            $('#' + UT_Id).val(parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)));            

            temp = parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0))
                        - parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0))
                        + parseInt(document.getElementById(UM_Id).oldvalue);
            if (temp >= 0) {
                $('#' + RM_Id).val(temp);
                $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));
            }
            else {
                $('#' + UM_Id).val(document.getElementById(UM_Id).oldvalue);
                $('#' + UT_Id).val(parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)));             
                alert("Beds in Reserve cannot be negative.");
            }
        }
        else if (curr_Id == "txtBedsUnavailableF") {
            if (document.getElementById("hdnRole").value == "HQ")
                document.getElementById("btnConfirm").disabled = false;
            $('#' + UT_Id).val(parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)));

            temp = parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0))
                        - parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0))
                        + parseInt(document.getElementById(UF_Id).oldvalue);
            if (temp >= 0) {
                $('#' + RF_Id).val(temp);
                $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));           
            }
            else {
                $('#' + UF_Id).val(document.getElementById(UF_Id).oldvalue);
                $('#' + UT_Id).val(parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)));               
                alert("Beds in Reserve cannot be negative.");
            }
        }
        else if (curr_Id == "txtFundedCapacityM"){            
            document.getElementById("btnConfirm").disabled = false;

            temp = parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0))
                    + parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0))
                    - document.getElementById(FM_Id).oldvalue;
            if (temp >= 0) {
                $('#' + RM_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0))
                    + parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0))
                    - document.getElementById(FM_Id).oldvalue);
                $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));
            }
            else
            {
                $('#' + FM_Id).val(document.getElementById(FM_Id).oldvalue);
                alert("Beds in Reserve cannot be negative.");
            }
        }
        else if (curr_Id == "txtFundedCapacityF"){
            document.getElementById("btnConfirm").disabled = false;
            temp = parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0))
                    + parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0))
                    - document.getElementById(FF_Id).oldvalue;
            if (temp >= 0) {
                $('#' + RF_Id).val(parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0))
                    + parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0))
                    - document.getElementById(FF_Id).oldvalue);
                $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));
            }
            else {
                $('#' + FF_Id).val(document.getElementById(FF_Id).oldvalue);
                alert("Beds in Reserve cannot be negative.");
            }
        }

        $('#' + RM_Id).val(parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0))
        - parseInt(iif($.isNumeric($('#' + EM_Id).val()), $('#' + EM_Id).val(), 0))
        - parseInt(iif($.isNumeric($('#' + IM_Id).val()), $('#' + IM_Id).val(), 0))
        - parseInt(iif($.isNumeric($('#' + CM_Id).val()), $('#' + CM_Id).val(), 0))
        - parseInt(iif($.isNumeric($('#' + UM_Id).val()), $('#' + UM_Id).val(), 0)));

        $('#' + RF_Id).val(parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0))
       - parseInt(iif($.isNumeric($('#' + EF_Id).val()), $('#' + EF_Id).val(), 0))
       - parseInt(iif($.isNumeric($('#' + IF_Id).val()), $('#' + IF_Id).val(), 0))
       - parseInt(iif($.isNumeric($('#' + CF_Id).val()), $('#' + CF_Id).val(), 0))
       - parseInt(iif($.isNumeric($('#' + UF_Id).val()), $('#' + UF_Id).val(), 0)));

        $('#' + RT_Id).val(parseInt(iif($.isNumeric($('#' + RM_Id).val()), $('#' + RM_Id).val(), 0)) + parseInt(iif($.isNumeric($('#' + RF_Id).val()), $('#' + RF_Id).val(), 0)));

        $('#' + TT_Id).val(parseInt(iif($.isNumeric($('#' + EM_Id).val()), $('#' + EM_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + EF_Id).val()), $('#' + EF_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + IM_Id).val()), $('#' + IM_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + IF_Id).val()), $('#' + IF_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + CM_Id).val()), $('#' + CM_Id).val(), 0))
                                 + parseInt(iif($.isNumeric($('#' + CF_Id).val()), $('#' + CF_Id).val(), 0)));

        $('#' + RC_Id).val(parseInt(iif($.isNumeric($('#' + FM_Id).val()), $('#' + FM_Id).val(), 0))
        + parseInt(iif($.isNumeric($('#' + FF_Id).val()), $('#' + FF_Id).val(), 0))
        - parseInt(iif($.isNumeric($('#' + TT_Id).val()), $('#' + TT_Id).val(), 0))        
        - parseInt(iif($.isNumeric($('#' + UT_Id).val()), $('#' + UT_Id).val(), 0))
        - parseInt(iif($.isNumeric($('#' + RT_Id).val()), $('#' + RT_Id).val(), 0)));

        $('#' + FT_Id).val(parseInt(iif($.isNumeric($('#' + TT_Id).val()), $('#' + TT_Id).val(), 0))           //Calculate total funded capacity
               + parseInt(iif($.isNumeric($('#' + RT_Id).val()), $('#' + RT_Id).val(), 0))
               + parseInt(iif($.isNumeric($('#' + UT_Id).val()), $('#' + UT_Id).val(), 0)));

    }
    $('#' + rowStatus).val("1");

    return true;
}



function iif(val1, val2, val3) {
    if (val1) {
        return val2;
    }
    else {
        return val3;
    }
}

function checkTransferORRDecision() {
    var DecisionId = $("#hdnORRDecisionRBLId").val();
    var CWPId = $('#hdnCW').val();
    var dDateId = $('#hdnORRDecisionDate').val();
    var dMakerId = $('#hdnORRDecisionMaker').val();
    var dRequestedDate = $('#hdnRequestedDate').val();
    var orrDecision = $("#" + DecisionId + " input:radio:checked").val();
    if (orrDecision == "Approve") {
        var errMsg = '';
        if (!$('#' + CWPId).val()) {
            errMsg += '"Case Coordinator Proposed Program" is required to approve.\n';
        }
        if (!$('#' + dDateId).val()) {
            errMsg += '"Date of Decision" is required to approve.\n';
        }
        if (!$('#' + dMakerId).val()) {
            errMsg += '"ORR Decision Maker" is required to approve.\n';
        }
        if (errMsg.length > 0) {
            alert(errMsg);
            return false;
        }
    }
    if ($('#' + dRequestedDate).val() == "") {
        alert("Requested Date is required.");
        return false;
    }
    return true;
}

function disableAndValidateButtons(button, group) {
    if (group) {
        if (Page_ClientValidate(group)) {
            $(button).parent().find("input").prop("disabled", true);
            return true;
        }
        else {
            return false;
        }
    }
    else {
        $(button).parent().find("input").prop("disabled", true);
        return true;
    }

};


function changeTo2k(sender, args) {
    // the current value is saved as args.Value;
    // you can modify the method of changing the value yourself.
    var year = args.Value.split("/")[2];
    if (year.substr(0, 2) == "00") {
        var newyear = "20" + year.substr(2, 2);
        $('#' + sender.TargetValidator).val(args.Value.substr(0, 6) + newyear);
    }
    else if (year.substr(0, 1) == "0") {
        var newyear = "2" + year.substr(1, 3);
        $('#' + sender.TargetValidator).val(args.Value.substr(0, 6) + newyear);
    }
    //    if (sender.TargetValidator.indexOf('txtAdmissionDate') > -1) {
    //        var minDate = "01/01/2000";
    //        var d = new Date();
    //        var maxDate = $.date(d);
    //        if (new Date(minDate) > new Date($('#' + sender.TargetValidator).val())) {
    //            alert("Admission Date cannot be before than 01/01/2000.");
    //            $('#' + sender.TargetValidator).val('');
    //        }
    //        if (new Date(maxDate) < new Date($('#' + sender.TargetValidator).val())) {
    //            alert("Admission Date cannot be future date.");
    //            $('#' + sender.TargetValidator).val('');
    //        }
    //    }
    //    if (sender.TargetValidator.indexOf('txtDOB') > -1 || sender.TargetValidator.indexOf('txtDOE') > -1 || sender.TargetValidator.indexOf('txtDOA') > -1) {

    //        if (sender.TargetValidator.indexOf('txtDOB') > -1 && year.indexOf(0) === 0) {
    //            var d = new Date();
    //            var maxDate = d.getFullYear().toString().substr(2, 2)
    //            var selectedYear = year.substr(2, 2);
    //            if (parseFloat(year) > parseFloat(maxDate)) {
    //                $('#' + sender.TargetValidator).val(args.Value.substr(0, 6) + '19' + selectedYear);
    //            }
    //        }
    //        else {
    //            var d = new Date();
    //            var maxDate = $.date(d);
    //            if (new Date(maxDate) < new Date($('#' + sender.TargetValidator).val())) {
    //                alert("The Date cannot be future date.");
    //                $('#' + sender.TargetValidator).val('');
    //            }
    //        }
    //    }

}

function validateFutureDate(oSrc, args) {
    var d = new Date();
    var maxDate = $.date(d);
    if (new Date(maxDate).getTime() < new Date(args.Value).getTime()) {
        args.IsValid = false;
        return;
    }

    if (oSrc.controltovalidate.indexOf('txtDOB') > -1) {
        if ($("#hdnDOBOrg").length > 0) {
            d.setYear(d.getYear() - 18);
            var newDate = d.toInputFormat(); //  dateArr[0] + "/" + dateArr[1] + "/" + year;
            if ($("#hdnDOBOrg").val() != "" && new Date($("#hdnDOBOrg").val()).getTime() != new Date(args.Value).getTime()) {

                if (new Date(newDate) > new Date(args.Value)) {
                    oSrc.errormessage = "Birth Day cannot be more than 18 years in the past.";
                    args.IsValid = false;
                }
                else {
                    args.IsValid = true;
                }
            }
            else if ($("#hdnDOBOrg").val() == "") {
                if (new Date(newDate) > new Date(args.Value)) {
                    oSrc.errormessage = "Birth Day cannot be more than 18 years in the past.";
                    args.IsValid = false;
                }
                else {
                    args.IsValid = true;
                }
            }
        }
    }
}
function loadFunctionPages(pageUrl, arg1, arg2) {
    $('#hdnSubProgId1').val(arg1);
    $('#hdnSIRID').val(arg1);
    $('#hdnSubProgId2').val(arg2);
    $("#hdnPageUrl").val(pageUrl);    

    if (pageUrl == "UACCaseReview_v2.aspx") {
        $('#hdnCaseReviewID').val(arg1);
    }

    if (pageUrl == "UACSIR.aspx") {
        $('#hdnEventType').val(arg2);
        $('#hdnAddendumID').val(1);
        document.forms[0].target = "_self";
        document.forms[0].action = pageUrl;
        document.forms[0].submit();
    }

    else if (arg2 || pageUrl == "UACCaseReview_v2.aspx" || pageUrl == "UACRiskAssessment.aspx" || pageUrl=="CaseMgtDetail.aspx") {
        document.forms[0].target = "_self";
        document.forms[0].action = pageUrl;
        document.forms[0].submit();
    }
    else {
        $("#btnHidden").click();
    }
}


function setSIRPages(arg1, arg2, arg3) {
    $('#hdnSIRID').val(arg1);
    $('#hdnEventID').val(arg2);
    $('#hdnFollowUpRPTID').val(arg3);
    //    //$("#hdnPageUrl").val(pageUrl);

    //    if (arg2) {
    //        document.forms[0].target = "_self";
    //        document.forms[0].action = pageUrl;
    //        document.forms[0].submit();
    //    }
    //    else {
    //        $("#btnHidden").click();
    //    }
}
function loadPdfForAddendum(pageUrl, arg1, arg2) {
    $('#hdnSIRID').val(arg1);
    $('#hdnAddendumID').val(1);
    $('#hdnEventType').val(arg2);
    $("#printBtnHidden").click();
}

function deleteAddendum(pageUrl, arg1) {
    $('#hdnSIRID').val(arg1);
    $("#deleteBtnHidden").click();
}

function resetForm() {
    if ($('#hdnSubProgId1').length > 0) {
        $('#hdnSubProgId1').val("");
    }
    if ($('#hdnSubProgId2').length > 0) {
        $('#hdnSubProgId2').val("");
    }
}



function generateRpt(arg) {
    $('#hdnSubProgId1').val("");
    $('#hdnSubProgId2').val(arg);
    document.forms[0].action = 'RptViewer.aspx';
    document.forms[0].target = '_blank';
    document.forms[0].submit();
}

function toggleHistoryGrid(imgId, gridId) {
    $("#" + imgId).attr('src', $("#" + imgId).attr('src') == "Images/plus.gif" ? "Images/minus.gif" : "Images/plus.gif");
    $("#" + gridId).slideToggle();
}

function togglePanel(imgId, panelId) {
    var cpe = $find(panelId);
    var imgSrc = $("#" + imgId).attr('src');
    if (cpe.get_Collapsed()) {
        cpe._doOpen();
        if (imgSrc.indexOf("plus.gif") != -1) {
            imgSrc = imgSrc.replace("plus.gif", "minus.gif");
            $("#" + imgId).attr('src', imgSrc);
        }
    } else {
        cpe._doClose();
        if (imgSrc.indexOf("minus.gif") != -1) {
            imgSrc = imgSrc.replace("minus.gif", "plus.gif");
            $("#" + imgId).attr('src', imgSrc);
        }
    }
}

function disableTextBox(chkId, txtId) {
    if (document.getElementById(chkId).checked) {
        $('#' + txtId).removeAttr('disabled');
    } else {
        $('#' + txtId).val("");
        $('#' + txtId).attr('disabled', 'disabled');
    }
}

function disableTextBoxForRadio(spanElement, txtId) {
    if (document.getElementById(spanElement).defaultValue == "1") {
        $('#' + txtId).removeAttr('disabled');
    } else {
        $('#' + txtId).val("");
        $('#' + txtId).attr('disabled', 'disabled');
    }
}

function toggleDivForRadio(spanElement, divClass) {
    var $inputElement = $(spanElement).children("input");
    if ($inputElement.val() == "1") {
        $('.' + divClass).show();
    } else {
        $('.' + divClass).hide();
    }
}

function toggleTr(imgId, trId) {
    var imgSrc = $("#" + imgId).attr('src');
    if (imgSrc.indexOf("plus.gif") != -1) {
        imgSrc = imgSrc.replace("plus.gif", "minus.gif");
        $("#" + imgId).attr('src', imgSrc);
        $("#" + trId).show();
    }
    else {
        imgSrc = imgSrc.replace("minus.gif", "plus.gif");
        $("#" + imgId).attr('src', imgSrc);
        $("#" + trId).hide();
    }
}

function getTBLTResult(testId) {
    $.ajax({
        type: "POST",
        url: "../UACWebServices.asmx/GetTBLTResult",
        data: "{testId: '" + testId + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
            var xmlDoc = $.parseXML(response.d);
            var xml = $(xmlDoc);
            var returls = xml.find("Table");
            //$('#TBLT_newddResult').removeOption(/./).addOption('', ' -- Select Result -- ');
            $('#TBLT_newddResult option').remove();
            $('#TBLT_newddResult').addOption(' -- Select Result -- ', '');
            $.each(returls, function () {
                var val = $.trim($(this).find("RESULT_ID").text());
                var text = $.trim($(this).find("DESCRIPTION").text());
                $('#TBLT_newddResult').addOption(text, val, false);
            });
        }
    });
}

function getWDCategory(wdId, callback) {
    var ajaxQuery = $.ajax({
        type: "POST",
        url: "../UACWebServices.asmx/getWDCategory",
        data: "{wdId: '" + wdId + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json"
    });
    ajaxQuery.done(function (response) {
        if (response.error) {
            output = false;
            alert(response.error);
        }
        else {
            if (response.d.toString() == "9") {
                if ($(".wdRuleOut input:checked").val() == "0") {
                    $(".divLT_Performed").hide();
                }
                else if ($(".wdRuleOut input:checked").val() == "1") {
                    $(".divLT_Performed").show();
                }
            }
            callback();
        }
    });
}

$.fn.addOption = function (optText, optValue) {
    var option = new Option(optText, optValue);
    return this.append(option);
};

$.fn.selectOption = function (toSelect) {
    var $option = this.find("option[value='" + toSelect + "']");
    if ($option.length > 0) {
        $option.prop("selected", "selected");
    } else {
        alert("option not found");
    }
};