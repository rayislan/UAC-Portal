﻿
$(document).ready(function () {


    $("select").each(function () {
        var dd = $(this);
        var specify = dd.parent().data().specify;
        if (specify) {
            if (dd.val() === "Other" || dd.val() === "NonUCMinorUC" || dd.val() === "Sponsor" || dd.val() === "NonSponsorRelative" || dd.val() === "StakeholderAdvocate") {
                $(specify).show();
            }
            else {
                $(specify).hide();
            }
        }
    }).change(function (event) {
        var specify = $(event.target).parent().data().specify;
        if (specify) {
            if ($(event.target).attr("id") === "gi_ddReporterType") {
                switch ($(event.target).val()) {
                    case "Sponsor":
                    case "NonSponsorRelative":
                    case "StakeholderAdvocate":
                    case "Other":
                        $(specify).show();
                        break;
                    default:
                        $(specify).val("")
                        $(specify).hide();
                        break;
                }
            }
            else {
                if ($(event.target).val() === 'Other' || $(event.target).val() === "NonUCMinorUC" || dd.val() === "Sponsor" || dd.val() === "NonSponsorRelative" || dd.val() === "StakeholderAdvocate") {
                    $(specify).show();
                } else {
                    $(specify).hide();
                }
            }
        }
    });
    

    $('.toggleImage').click(function (event) {
        var open = $(this).attr('src') == "Images/minus.gif";
        var panelId = $(event.target).data().panelid;

        if (hotlineAlertId === '' && panelId !== '#pnlGeneralInfo') {
            return;
        }

        if (hotlineAlertId !== '') {
            $.each($('.toggleImage'), function (index, item) {
                $($(item).data().panelid).hide();
                $(this).attr('src', "Images/plus.gif");
            });
        }


        if (open) {
            $(this).attr('src', "Images/plus.gif");
            $(panelId).hide();
        } else {
            $(this).attr('src', "Images/minus.gif");
            $(panelId).show();
        }
    });




    $('#rp_rbReportedToLaw').change(function (event, disabled) {
        if ($(event.target)[0].id == 'rp_rbReportedToLaw_0' || disabled == '0') {
            $("#paneldlLaw").find("input[type='text']").val('').prop("disabled", true);
            $("#paneldlLaw").find("select").val('None').prop("disabled", true);
        }
        else {
            $("#paneldlLaw").find("input[type='text']").prop("disabled", false);
            $("#paneldlLaw").find("select").prop("disabled", false);
        }
    });

    $('#rp_rbReportedToCPS').change(function (event, disabled) {
        if ($(event.target)[0].id == 'rp_rbReportedToCPS_0' || disabled == '0') {
            $("#paneldCPS").find("input[type='text']").val('').prop("disabled", true);
            $("#paneldCPS").find("select").val('None').prop("disabled", true);
        }
        else {
            $("#paneldCPS").find("input[type='text']").prop("disabled", false);
            $("#paneldCPS").find("select").prop("disabled", false);
        }
    });

    $('#gi_btnCancel').click(function (event) {
        this.form.reset();
        $("#pnlGeneralInfo").find("input[type='text']").val('');
        $("#pnlGeneralInfo").find("input[type='radio']").val('0');
        $("#pnlGeneralInfo").find("select").val('None');
        if (typeof (Page_ValidationSummaries) == "undefined")
            return;
        for (var i = 0; i < Page_ValidationSummaries.length; i++) {
            Page_ValidationSummaries[i].style.display = "none";
        }
        return false;
    });

    $('#rp_btnCancel').click(function (event) {
        this.form.reset();
        $("#pnlReporting").find("input[type='text']").val('');
        $("#pnlReporting").find("input[type='radio']").val('0');
        $("#pnlReporting").find("select").val('None');
        if (typeof (Page_ValidationSummaries) == "undefined")
            return;
        for (var i = 0; i < Page_ValidationSummaries.length; i++) {
            Page_ValidationSummaries[i].style.display = "none";
        }
        return false;
    });

    $('#in_btnCancel').click(function (event) {
        this.form.reset();
        $("#pnlIncidentInfo").find("input[type='text']").val('');
        $("#pnlIncidentInfo").find("input[type='radio']").val('0');
        $("#pnlIncidentInfo").find("textarea").val('');
        $("#pnlIncidentInfo").find("select").val('None');
        $('#in_tbProgramCity').val('').prop("disabled", false);
        $('#in_tbProgramState').val('').prop("disabled", false);
        if (typeof (Page_ValidationSummaries) == "undefined")
            return;
        for (var i = 0; i < Page_ValidationSummaries.length; i++) {
            Page_ValidationSummaries[i].style.display = "none";
        }
        return false;
    });
});



function setProgamCityAndState(selectedProgram) {
    var program = programs[$(selectedProgram).val()];
    if (program !== undefined) {
        $('#in_tbProgramCity').val(program.City).prop("disabled", true); ;
        $('#in_tbProgramState').val(program.State).prop("disabled", true); ;
    }
    else {
        $('#in_tbProgramCity').val('').prop("disabled", false); ;
        $('#in_tbProgramState').val('').prop("disabled", false); ;
    }
}

function validateReportedToCPS(sender, args) {
    if ($(sender).parents(".reportedTable").find(".stateList").attr("id") === $('#' + sender.controltovalidate).attr("id")) {
        if ($('#rp_rbReportedToCPS').find("input:checked").val() == '1' && args.Value == 'None' && $(sender).data().index == 1) {
            args.IsValid = false;
        }
    }
    else {
        var stateVal = $(sender).parents(".reportedTable").find(".stateList").val();
        if (stateVal !== "None" && args.Value == '') {
            args.IsValid = false;
        }
    }
}

function validateSpecifyBox(sender, args) {
    var ddVal = $($(sender).data().dropdown).val();
    if ((ddVal == "Other" || ddVal == "NonUCMinorUC" || ddVal === "Sponsor" || ddVal === "NonSponsorRelative" || ddVal === "StakeholderAdvocate") && args.Value == "") {
        args.IsValid = false;
    }
}

function validateReportedToLaw(sender, args) {
    if ($(sender).parents(".lawTable").find(".stateList").attr("id") === $('#' + sender.controltovalidate).attr("id")) {
        if ($('#rp_rbReportedToLaw').find("input:checked").val() == '1' && args.Value == 'None' && $(sender).data().index == 1) {
            args.IsValid = false;
        }
    }
    else {
        var stateVal = $(sender).parents(".lawTable").find(".stateList").val();
        if (stateVal !== "None" && args.Value == '') {
            args.IsValid = false;
        }
    }
}

function validateRB(sender, args) {
    if (args.Value == '1' && $($(sender).data().textbox).val() == '') {
        $($(sender).data().textbox).prop("disabled", false);
        if ($(sender).data().datefield) {
            $($(sender).data().datefield).prop("disabled", false);
        }
        args.IsValid = false;
    }
    else if(args.Value == '0') {
        $($(sender).data().textbox).prop("disabled", true); ;
        if ($(sender).data().datefield) {
            $($(sender).data().datefield).prop("disabled", true);
        }
        $($(sender).data().textbox).val('');
        if ($($(sender).data().datebox)) {
            $($(sender).data().datebox).val('');
        }
    }
}


function validateDate(sender, args) {
    try {
        var year = args.Value.split("/")[2];
        if (year.substr(0, 2) == "00") {
            var newyear = "20" + year.substr(2, 2);
            $('#' + sender.TargetValidator).val(args.Value.substr(0, 6) + newyear);
        }
        else if (year.substr(0, 1) == "0") {
            var newyear = "2" + year.substr(1, 3);
            $('#' + sender.TargetValidator).val(args.Value.substr(0, 6) + newyear);
        }
        sender.InvalidValueMessage = "Invalid Date";
        var d = new Date();
        var maxDate = $.date(d);
        var currDate = $.date(new Date(args.Value));
        if (new Date(currDate).getTime() > new Date(maxDate).getTime()) {
            args.IsValid = false;
            if ($(sender).data().showasterisk) {
                sender.InvalidValueMessage = "*";
            }
            else {
                sender.InvalidValueMessage = "Date cannot be in the future date";
            }
        }
    } catch (e) {
        args.IsValid = false;
    }
}

function disableAll() {
    $('input').prop("disabled", true);
}

function saveAndSendHotlineAlert(button, groupArray) {
    var error = false;
    $.each(groupArray, function (index, item) {
        if (!Page_ClientValidate(item)) {
            error = true;
            return;
        }
    });

    if (error) {
        return false;
    }
    else {
        $(button).prop("disabled", true);
        return true;
    }
}

function saveAndSendHotlineAlert(button) {
    var isGrpOneValid = Page_ClientValidate("ReportingValidationGroup");
    var isGrpTwoValid = Page_ClientValidate("IncidentInfoInfoValidationGroup");
    var isGrpThreeValid = Page_ClientValidate("GeneralInfoValidationGroup");

    var i;
    for (i = 0; i < Page_Validators.length; i++) {
        ValidatorValidate(Page_Validators[i]); //this forces validation in all groups
    }

    //display all summaries.
    for (i = 0; i < Page_ValidationSummaries.length; i++) {
        summary = Page_ValidationSummaries[i];
        //does this summary need to be displayed?
        if (fnJSDisplaySummary(summary.validationGroup)) {
            summary.style.display = ""; //"none"; "inline";
        }
    }
   
    var element = null;
    if (!isGrpThreeValid) {
        $('#pnlGeneralInfo').show();
        element = $('#gi_buttonSave');
    }
    else if (!isGrpTwoValid) {
        $('#pnlIncidentInfo').show();
        element = $('#in_buttonSave');
    }
    else if(!isGrpOneValid) {
        $('#pnlReporting').show();
        element = $('#rp_buttonSave');

    }
    if (element) {
            $('html, body').animate({
                scrollTop: element.offset().top
            }, 2000);
    }


    if (isGrpOneValid && isGrpTwoValid && isGrpThreeValid) {
        $("input[type='button']").prop("disabled", true);
        callPostBack();
    }
    else {
        return false;
    }
}


/* determines if a Validation Summary for a given group needs to display */
function fnJSDisplaySummary(valGrp) {
    var rtnVal = false;
    for (i = 0; i < Page_Validators.length; i++) {
        if (Page_Validators[i].validationGroup == valGrp) {
            if (!Page_Validators[i].isvalid) { //at least one is not valid.
                rtnVal = true;
                break; //exit for-loop, we are done.
            }
        }
    }
    return rtnVal;
}

function saveHotlineAlert(button, group) {
    if (group) {
        if (Page_ClientValidate(group)) {
            $(button).parent().find("input").prop("disabled", true);
            return true;
        }
        else {
            return false;
        }
    }
    else {
        $(button).parent().find("input").prop("disabled", true);
        return true;
    }
    
};

function validateReportedDate(sender, args) {
    if ($($(sender).data().radio).find("input:checked").val() == '1' && args.Value == '') {
        args.IsValid = false;
    }
}

function searchHotlineAlerts(button, group) {
    
    if (Page_ClientValidate(group)) {
        $(button).prop("disabled", true);
        return true;
    }
    else {
        for (var i = 0; i < Page_ValidationSummaries.length; i++) {
            if (Page_ValidationSummaries[i].innerHTML.indexOf("*") > -1) {
                Page_ValidationSummaries[i].innerHTML = "<ul><li>Date cannot be in the future date</li></ul>";
            }
        }   
        $('.validator').text('*');
        return false;
    }
};

function validate(s, args) {
    if ($('#gi_ddLanguage').val() === 'Other' && $('#gi_tbLangOther').val().trim() === '') {
        args.IsValid = false;
    }
}

function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function validateNumber(sender, args) {
    if (!isNumeric(args.Value)) {
        args.IsValid = false;
    }
}


function validateHotlineId(s, args) {
    if ($('#gi_tbhotlineid').val().trim() != '' && !isNumeric($('#gi_tbhotlineid').val().trim())) {
        args.IsValid = false;
        s.errormessage = "Hotline Id has to be a number";
    }
}

function validateEmptyText(sender, args) {
    if ($('#' + sender.controltovalidate).val().trim() === "") {
        args.IsValid = false;
    }
}

function validateSearch(s, args) {
    if ($('#gi_tbdate').val().trim() === '' && $('#gi_tbhotlineid').val().trim() === '') {
        args.IsValid = false;
        s.errormessage = "Date of Call to Hotline or Hotline ID is required"
    }
  
}